# Line Chart by Venkata Karthik Thota
Animated D3.js Line Chart of Energy Per Capita (2000 - 2010) of BRICS + USA.