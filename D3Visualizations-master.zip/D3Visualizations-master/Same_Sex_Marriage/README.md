# Same Sex Marriage by Venkata Karthik Thota
Same Sex Marriage Across the World using D3.js 

