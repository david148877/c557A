# Bar Chart by Venkata Karthik Thota  
Static D3.js Bar Graph of 2012 GDP of 10 nations. 

