# ComparingSFandLA
Comparing SF and LA Neighborhoods 


Project originally created by following students in CMPS 165 (Sporing 2015) with guidance from the instructor Suresh Lodha and Teaching Assitant Venkata Karthik Thota: Kyle Kiminki, Michael Stirchak, Ryan Brounley, Dylan Woodbury
  
Project hosted above with more modifications by Venkat Karthik Thota and Suresh Lodha
University of Caliornia, Santa Cruz